<?php

// Note, this will be updated automatically during grunt release task
$ET_BUILDER_VERSION = '3.17.3';
