<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
} ?>
<h1 class="wps-title">
	<div class="wps-logo-img">
		<a href="https://www.wpserveur.net/?refwps=14&campaign=wpslimitlogin" target="_blank">
			<img src="<?php echo WPS_LIMIT_LOGIN_URL . 'assets/img/wps-limit-login-logo.png'; ?>" alt="WPS Limit Login" />
		</a>
	</div>
</h1>