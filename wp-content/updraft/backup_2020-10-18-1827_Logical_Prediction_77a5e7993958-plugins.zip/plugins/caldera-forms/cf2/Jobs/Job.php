<?php


namespace calderawp\calderaforms\cf2\Jobs;


abstract class Job extends \WP_Queue\Job
{

}