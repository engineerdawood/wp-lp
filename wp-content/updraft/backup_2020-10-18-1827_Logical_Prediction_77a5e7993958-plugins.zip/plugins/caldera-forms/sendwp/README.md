# SendWP Integration

Both `handler.php` and `installer.js` are dependency scripts of the SendWP SDK.