=== Flip Cards Module For Divi===
Contributors: themeythemes
Tags: divi, divi flip card, flip box
Requires at least: 5.0
Tested up to: 5.5
Requires PHP: 5.6
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple plugin that adds a flip cards module in the Divi builder.

== Description ==

This plugin adds a new Flip Cards module in the Divi Builder. Once you activate the plugin a new module will appear in your module list by the name of Flip Cards. You can then use the module to add Flip Cards anywhere inside the Divi Builder. You can choose from any one of the 4 directions for the flip animation Up, Down, Left or Right. The plugin is Visual Builder supported and comes with a lot of options to customize both the front and back cards.

**Features**

* Set the animation direction for Flip
* Choose any Divi Icon for the Front Card and the Back Card
* Set styles for Title, Body and Icons
* Option to use an image instead of an icon on the cards
* Option to set background color for each card

[Flip Cards Demo](https://www.learnhowwp.com/divi-flip-cards-plugin)

**Other Divi Plugins**
[Divi Breadcrumbs Module](https://wordpress.org/plugins/breadcrumbs-divi-module/)
[Divi Overlay on Images Module](https://wordpress.org/plugins/overlay-image-divi-module/)


== Frequently Asked Questions ==
= Where can I access the module? =
 
After you activate the plugin a module should automatically appear in the module list. The name of the module is Flip Cards.  

== Changelog ==

= 0.9.1 =
* Fixed issue with html showing in the body area in the Visual Builder.
* Added option for animation duration and animation timing function.